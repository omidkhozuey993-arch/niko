from fastapi import FastAPI, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel, Field
import edge_tts

app = FastAPI(title="Niko Persian TTS")

class SpeechRequest(BaseModel):
    text: str = Field(min_length=1, max_length=3000)
    voice: str = "fa-IR-FaridNeural"

@app.get("/health")
async def health():
    return {"ok": True, "voice": "fa-IR-FaridNeural"}

@app.post("/tts")
async def tts(req: SpeechRequest):
    if req.voice != "fa-IR-FaridNeural":
        raise HTTPException(status_code=400, detail="Unsupported voice")
    try:
        speaker = edge_tts.Communicate(req.text, req.voice, rate="+4%", pitch="+2Hz")
        audio = bytearray()
        async for chunk in speaker.stream():
            if chunk["type"] == "audio":
                audio.extend(chunk["data"])
        if not audio:
            raise RuntimeError("No audio returned")
        return Response(bytes(audio), media_type="audio/mpeg")
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"TTS provider error: {exc}")
