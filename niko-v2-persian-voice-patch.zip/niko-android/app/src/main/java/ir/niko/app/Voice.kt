package ir.niko.app

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

/** Persian speech recognition + Persian male cloud TTS fallback. */
class Voice(
    private val ctx: Context,
    private val onHeard: (String) -> Unit,
    private val onProblem: (String) -> Unit
) {
    companion object {
        // Replace with your deployed HTTPS backend URL. Do not put provider secrets in the APK.
        private const val CLOUD_TTS_URL = "https://YOUR-NIKO-TTS-SERVER.example/tts"
    }

    private val main = Handler(Looper.getMainLooper())
    private val network = Executors.newSingleThreadExecutor()
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var paused = false
    private var speaking = false
    private var player: MediaPlayer? = null
    var active = false
        private set
    private val restart = Runnable { begin() }

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale("fa", "IR")) ?: TextToSpeech.LANG_NOT_SUPPORTED
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
                tts?.setPitch(1.12f)
            }
        }
    }

    fun start() { active = true; paused = false; main.post { begin() } }
    fun stop() { active = false; main.removeCallbacks(restart); destroyRec() }

    fun shutdown() {
        stop()
        try { player?.stop() } catch (_: Exception) {}
        player?.release(); player = null
        tts?.stop(); tts?.shutdown(); tts = null
        network.shutdownNow()
    }

    fun speak(text: String, done: () -> Unit) {
        if (text.isBlank()) { done(); return }
        speaking = true
        pauseListening()
        if (ttsReady && tts != null) {
            val engine = tts!!
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { main.post { afterSpeech(done) } }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { main.post { useCloud(text, done) } }
                override fun onError(utteranceId: String?, errorCode: Int) { main.post { useCloud(text, done) } }
            })
            val result = engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "niko-${System.currentTimeMillis()}")
            if (result == TextToSpeech.ERROR) useCloud(text, done)
        } else useCloud(text, done)
    }

    private fun useCloud(text: String, done: () -> Unit) {
        network.execute {
            var conn: HttpURLConnection? = null
            try {
                check(!CLOUD_TTS_URL.contains("YOUR-NIKO-TTS-SERVER")) {
                    "آدرس سرویس صدای ابری هنوز تنظیم نشده است؛ راهنمای cloud-tts را ببینید"
                }
                conn = (URL(CLOUD_TTS_URL).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 15000; readTimeout = 60000; doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val body = JSONObject().put("text", text).put("voice", "fa-IR-FaridNeural").toString()
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                check(conn.responseCode in 200..299) { "خطای سرویس گفتار: HTTP ${conn.responseCode}" }
                val file = File(ctx.cacheDir, "niko-${System.currentTimeMillis()}.mp3")
                conn.inputStream.use { input -> file.outputStream().use { output -> input.copyTo(output) } }
                main.post {
                    try {
                        player?.release()
                        player = MediaPlayer().apply {
                            setDataSource(file.absolutePath)
                            setOnCompletionListener { release(); player = null; file.delete(); afterSpeech(done) }
                            setOnErrorListener { mp, _, _ ->
                                mp.release(); player = null; file.delete()
                                onProblem("پخش صدای نیکو انجام نشد")
                                afterSpeech(done); true
                            }
                            prepare(); start()
                        }
                    } catch (e: Exception) {
                        file.delete(); onProblem("خطا در پخش صدا: ${e.message}"); afterSpeech(done)
                    }
                }
            } catch (e: Exception) {
                main.post { onProblem(e.message ?: "اتصال به سرویس صدای نیکو برقرار نشد"); afterSpeech(done) }
            } finally { conn?.disconnect() }
        }
    }

    private fun afterSpeech(done: () -> Unit) {
        speaking = false; paused = false
        if (active) scheduleRestart(350)
        done()
    }
    private fun pauseListening() { paused = true; main.removeCallbacks(restart); try { rec?.cancel() } catch (_: Exception) {} }
    private fun scheduleRestart(ms: Long) { main.removeCallbacks(restart); main.postDelayed(restart, ms) }
    private fun destroyRec() { try { rec?.destroy() } catch (_: Exception) {}; rec = null }

    private fun begin() {
        if (!active || paused || speaking) return
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { active = false; onProblem("تشخیص گفتار روی این گوشی نصب نیست"); return }
        if (rec == null) rec = SpeechRecognizer.createSpeechRecognizer(ctx).also { it.setRecognitionListener(listener) }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fa-IR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        try { rec?.startListening(intent) } catch (_: Exception) { destroyRec(); scheduleRestart(1500) }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
        override fun onResults(results: Bundle?) {
            val result = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!result.isNullOrBlank()) onHeard(result)
            if (active && !paused) scheduleRestart(250)
        }
        override fun onError(error: Int) {
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { active = false; onProblem("اجازه میکروفون داده نشده") }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> { destroyRec(); if (active && !paused) scheduleRestart(1200) }
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> if (active && !paused) scheduleRestart(150)
                else -> if (active && !paused) scheduleRestart(900)
            }
        }
    }
}
