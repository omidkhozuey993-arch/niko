package ir.niko.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** The things Niko can do on the phone. Each one is a tool Claude can call. */
object Phone {

    private const val NO_ACCESS =
        "error: the accessibility service is off. Tell the user to turn Niko on in Settings > Accessibility."

    fun run(ctx: Context, name: String, a: JSONObject): String {
        return try {
            when (name) {
                "get_time" -> timeInfo()
                "open_app" -> openApp(ctx, a.getString("name"))
                "open_settings" -> openSettings(ctx, a.getString("page"))
                "open_url" -> {
                    launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("url"))))
                    pause(1500)
                    "opened"
                }
                "read_screen" -> NikoAccess.instance?.readScreen() ?: NO_ACCESS
                "tap" -> {
                    val acc = NikoAccess.instance ?: return NO_ACCESS
                    val r = acc.tap(a.getInt("id"))
                    pause(800)
                    r
                }
                "tap_xy" -> {
                    val acc = NikoAccess.instance ?: return NO_ACCESS
                    val ok = acc.tapAt(a.getDouble("x").toFloat(), a.getDouble("y").toFloat())
                    pause(800)
                    if (ok) "tapped" else "error: tap failed"
                }
                "set_text" -> {
                    val acc = NikoAccess.instance ?: return NO_ACCESS
                    acc.setText(a.getInt("id"), a.getString("text"))
                }
                "scroll" -> {
                    val acc = NikoAccess.instance ?: return NO_ACCESS
                    val r = acc.scroll(a.getString("direction") == "down")
                    pause(600)
                    r
                }
                "press" -> press(a.getString("button"))
                "wait" -> {
                    pause((a.optInt("seconds", 1).coerceIn(1, 5)) * 1000L)
                    "waited"
                }
                "set_alarm" -> {
                    val i = Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, a.getInt("hour"))
                        .putExtra(AlarmClock.EXTRA_MINUTES, a.getInt("minute"))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "نیکو"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    launch(ctx, i)
                    pause(800)
                    "alarm set"
                }
                "set_timer" -> {
                    val i = Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, a.getInt("seconds"))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "نیکو"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    launch(ctx, i)
                    pause(800)
                    "timer started"
                }
                "dial" -> {
                    launch(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + a.getString("number"))))
                    pause(1200)
                    "dialer opened (the user must press call)"
                }
                else -> "error: unknown tool $name"
            }
        } catch (e: Exception) {
            "error: ${e.message}"
        }
    }

    private fun pause(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (_: InterruptedException) {
        }
    }

    private fun launch(ctx: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    fun timeInfo(): String {
        val now = Date()
        val g = SimpleDateFormat("yyyy-MM-dd HH:mm, EEEE", Locale.US).format(now)
        val j = try {
            val f = android.icu.text.SimpleDateFormat("EEEE d MMMM y", Locale("fa", "IR"))
            f.setCalendar(android.icu.util.PersianCalendar())
            f.format(now)
        } catch (e: Exception) {
            ""
        }
        return "Gregorian: $g; Jalali: $j"
    }

    private fun openApp(ctx: Context, query: String): String {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val q = query.trim().lowercase()
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return "error: no app matches '$query'. Installed apps: " +
                apps.map { it.loadLabel(pm).toString() }.sorted().take(60).joinToString(", ")
        val li = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return "error: cannot launch"
        launch(ctx, li)
        pause(1500)
        return "opened " + hit.loadLabel(pm)
    }

    private fun openSettings(ctx: Context, page: String): String {
        val action = when (page) {
            "date_time" -> Settings.ACTION_DATE_SETTINGS
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "language" -> Settings.ACTION_LOCALE_SETTINGS
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        launch(ctx, Intent(action))
        pause(1500)
        return "opened settings page: $page"
    }

    private fun press(button: String): String {
        val acc = NikoAccess.instance ?: return NO_ACCESS
        val code = when (button) {
            "back" -> AccessibilityService.GLOBAL_ACTION_BACK
            "home" -> AccessibilityService.GLOBAL_ACTION_HOME
            "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
            "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
            "lock_screen" -> AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN
            else -> return "error: unknown button $button"
        }
        val ok = acc.performGlobalAction(code)
        pause(700)
        return if (ok) "done" else "error: failed"
    }
}
