package ir.niko.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Talks to Claude. Runs a small agent loop: Claude may call phone tools several times
 * (open settings, read the screen, tap...) before giving a final spoken answer.
 * Call [ask] from a background thread only.
 */
class Brain(private val ctx: Context) {

    companion object {
        const val MODEL = "claude-sonnet-5-5"
        private const val MAX_STEPS = 16

        private const val SYSTEM = """You are Niko (نیکو), a cute little robot assistant who lives on the user's Android phone screen.
The user talks to you by voice in Persian, and your final reply is read aloud. Reply in short, warm, colloquial Persian: one to three sentences, plain text only, no markdown, no emoji, no lists.

You can act on the phone with tools. For tasks that need the phone's screens:
1. Open the right place first (open_settings is the fastest way to reach a Settings page; open_app for apps).
2. read_screen, then act with tap / set_text / scroll / press.
3. read_screen again to verify the result. Never say you are done unless you saw it on screen. If the screen still looks old, wait(1) and read again.
Android does not let apps change settings silently, so you move through the real screens step by step, like a person.

Safety rules:
- Before anything that costs money, deletes data, sends a message or email, places a call, posts publicly, or changes security settings or passwords, first ask the user for a clear yes in your reply and wait for it.
- Never read out or type passwords, PINs, card numbers or one-time codes.
- If the user says stop, stop right away.
- If a tool says the accessibility service is off, tell the user to turn Niko on in Settings > Accessibility.
- If you cannot do something, say so plainly and suggest what the user can do.

The user lives in Iran (Asia/Tehran). Phone screens may show Gregorian or Jalali dates; when a date matters and it is unclear, ask which one they mean."""
    }

    private val history = JSONArray()
    private var lastUse = 0L

    private fun str(desc: String, options: List<String>? = null): JSONObject {
        val o = JSONObject().put("type", "string").put("description", desc)
        if (options != null) o.put("enum", JSONArray(options))
        return o
    }

    private fun num(desc: String): JSONObject =
        JSONObject().put("type", "integer").put("description", desc)

    private fun tool(name: String, desc: String, props: JSONObject = JSONObject(), required: List<String> = emptyList()): JSONObject =
        JSONObject()
            .put("name", name)
            .put("description", desc)
            .put(
                "input_schema",
                JSONObject().put("type", "object").put("properties", props).put("required", JSONArray(required))
            )

    private val tools: JSONArray by lazy {
        JSONArray()
            .put(tool("get_time", "Get the phone's current date and time (Gregorian and Jalali)."))
            .put(tool("open_app", "Open an installed app by its name.", JSONObject().put("name", str("App name, as shown under its icon")), listOf("name")))
            .put(
                tool(
                    "open_settings", "Open a page of the phone's Settings app.",
                    JSONObject().put(
                        "page",
                        str(
                            "Which page",
                            listOf("main", "date_time", "wifi", "bluetooth", "display", "sound", "apps", "battery", "accessibility", "location", "airplane", "language", "storage")
                        )
                    ),
                    listOf("page")
                )
            )
            .put(tool("open_url", "Open a web address in the browser.", JSONObject().put("url", str("Full https address")), listOf("url")))
            .put(tool("read_screen", "Read what is on the screen now. Returns numbered elements like [3] Button \"OK\" clickable. Use those numbers with tap, set_text and scroll."))
            .put(tool("tap", "Tap a screen element by its number from the latest read_screen.", JSONObject().put("id", num("Element number")), listOf("id")))
            .put(tool("tap_xy", "Tap at screen pixel coordinates. Only when tap cannot reach the element.", JSONObject().put("x", num("x pixel")).put("y", num("y pixel")), listOf("x", "y")))
            .put(tool("set_text", "Type text into an editable element.", JSONObject().put("id", num("Element number")).put("text", str("Text to type")), listOf("id", "text")))
            .put(tool("scroll", "Scroll the first scrollable area of the latest read_screen.", JSONObject().put("direction", str("down shows content further down", listOf("up", "down"))), listOf("direction")))
            .put(tool("press", "Press a system button or open a system panel.", JSONObject().put("button", str("Which one", listOf("back", "home", "recents", "notifications", "quick_settings", "lock_screen"))), listOf("button")))
            .put(tool("wait", "Wait a few seconds for the screen to change.", JSONObject().put("seconds", num("1 to 5")), listOf("seconds")))
            .put(tool("set_alarm", "Set an alarm clock.", JSONObject().put("hour", num("0-23")).put("minute", num("0-59")).put("label", str("Label")), listOf("hour", "minute")))
            .put(tool("set_timer", "Start a countdown timer.", JSONObject().put("seconds", num("Length in seconds")).put("label", str("Label")), listOf("seconds")))
            .put(tool("dial", "Open the dialer with a number filled in. The user presses call.", JSONObject().put("number", str("Phone number")), listOf("number")))
    }

    fun ask(question: String, onTool: (String) -> Unit): String {
        val key = Prefs.apiKey(ctx)
        if (key.isBlank()) return "اول باید کلید API رو توی برنامه‌ی نیکو وارد کنی."
        val now = System.currentTimeMillis()
        if (now - lastUse > 10 * 60 * 1000 || history.length() > 40) clearHistory()
        lastUse = now

        history.put(JSONObject().put("role", "user").put("content", question))
        try {
            for (step in 0 until MAX_STEPS) {
                val resp = call(key)
                val content = resp.getJSONArray("content")
                history.put(JSONObject().put("role", "assistant").put("content", content))

                val results = JSONArray()
                val sb = StringBuilder()
                for (i in 0 until content.length()) {
                    val b = content.getJSONObject(i)
                    when (b.getString("type")) {
                        "text" -> sb.append(b.getString("text"))
                        "tool_use" -> {
                            val name = b.getString("name")
                            onTool(name)
                            val out = Phone.run(ctx, name, b.optJSONObject("input") ?: JSONObject())
                            results.put(
                                JSONObject()
                                    .put("type", "tool_result")
                                    .put("tool_use_id", b.getString("id"))
                                    .put("content", out)
                            )
                        }
                    }
                }
                if (results.length() == 0) {
                    val t = sb.toString().replace(Regex("[*#_`>]"), "").trim()
                    return if (t.isEmpty()) "انجام شد." else t
                }
                history.put(JSONObject().put("role", "user").put("content", results))
            }
            return "این کار برام خیلی طولانی شد. می‌خوای دوباره امتحان کنم؟"
        } catch (e: Exception) {
            clearHistory()
            val m = e.message ?: ""
            return when {
                m.startsWith("HTTP 401") -> "کلید API درست نیست. توی برنامه‌ی نیکو دوباره واردش کن."
                m.startsWith("HTTP 429") -> "الان خیلی شلوغه، چند لحظه‌ی دیگه دوباره صدام کن."
                m.startsWith("HTTP 400") && m.contains("credit", true) -> "اعتبار حساب API تموم شده."
                m.startsWith("HTTP") -> "یه مشکل از سمت سرور پیش اومد: " + m.take(120)
                else -> "به اینترنت وصل نشدم. اتصالت رو چک می‌کنی؟"
            }
        }
    }

    private fun clearHistory() {
        while (history.length() > 0) history.remove(0)
    }

    private fun call(key: String): JSONObject {
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 1024)
            .put("system", SYSTEM + "\n\nNow: " + Phone.timeInfo())
            .put("tools", tools)
            .put("messages", history)

        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 90000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", key)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw RuntimeException("HTTP $code $text")
            return JSONObject(text)
        } finally {
            conn.disconnect()
        }
    }
}
