package ir.niko.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.math.sin

/** Niko himself, drawn with a Canvas. Set [act] to change what he is doing. */
class NikoView(ctx: Context) : View(ctx) {

    @Volatile
    var act: String = "idle"

    @Volatile
    var dir: Int = 1

    private var clock = 0f
    private var last = 0L
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()

    private val shell = 0xFFF4F7FB.toInt()
    private val shellD = 0xFFC9D3E6.toInt()
    private val limb = 0xFF8E9BBD.toInt()
    private val screen = 0xFF1C2340.toInt()
    private val eye = 0xFF6FF3E0.toInt()
    private val cheek = 0xFFFF9DB1.toInt()
    private val glow = 0xFFFFC83D.toInt()

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        if (last != 0L) clock += ((now - last) / 1000f).coerceAtMost(0.1f)
        last = now
        val s = width / 120f
        c.save()
        c.scale(s, s)
        if (dir < 0) {
            c.translate(120f, 0f)
            c.scale(-1f, 1f)
        }
        drawRobot(c)
        c.restore()
        postInvalidateOnAnimation()
    }

    private fun rr(c: Canvas, l: Float, tp: Float, r: Float, b: Float, rad: Float, col: Int) {
        p.style = Paint.Style.FILL
        p.color = col
        rect.set(l, tp, r, b)
        c.drawRoundRect(rect, rad, rad, p)
    }

    private fun oval(c: Canvas, l: Float, tp: Float, r: Float, b: Float, col: Int, alpha: Int = 255) {
        p.style = Paint.Style.FILL
        p.color = col
        p.alpha = alpha
        rect.set(l, tp, r, b)
        c.drawOval(rect, p)
        p.alpha = 255
    }

    private fun dot(c: Canvas, cx: Float, cy: Float, r: Float, col: Int, alpha: Int = 255) {
        oval(c, cx - r, cy - r, cx + r, cy + r, col, alpha)
    }

    private inline fun rot(c: Canvas, deg: Float, px: Float, py: Float, body: () -> Unit) {
        c.save()
        c.rotate(deg, px, py)
        body()
        c.restore()
    }

    private fun drawRobot(c: Canvas) {
        val tt = clock
        var legL = 0f
        var legR = 0f
        var armL = 0f
        var armR = 0f
        var head = 0f
        var bob = -0.8f - 0.8f * sin(tt * 2.6f)
        var eyeOpen = 1f
        var eyeDx = 0f
        var eyeDy = 0f
        var talk = false
        var prop = 0
        var zzz = false
        var notes = false
        var pulseSpeed = 3f

        val blink = tt % 4.8f
        if (blink > 4.55f && blink < 4.75f) eyeOpen = 0.1f

        when (act) {
            "walk" -> {
                val w = sin(tt * 7f)
                legL = 26f * w
                legR = -26f * w
                armL = -18f * w
                armR = 18f * w
                bob = -abs(w) * 3f
            }
            "dance" -> {
                val w = sin(tt * 9f)
                bob = -abs(w) * 9f
                head = 9f * sin(tt * 4.6f)
                armL = 150f + 14f * w
                armR = -150f - 14f * w
                legL = 18f * w
                legR = -18f * w
                notes = true
            }
            "wave" -> {
                armR = -150f + 22f * sin(tt * 16f)
                head = -5f
            }
            "read" -> {
                armL = -78f
                armR = 78f
                head = 7f
                eyeDy = 3f
                prop = 1
            }
            "sleep" -> {
                eyeOpen = 0.1f
                head = 11f
                zzz = true
                bob = -0.8f - 1.2f * sin(tt * 1.6f)
                pulseSpeed = 1.2f
            }
            "look" -> {
                eyeDx = 5f * sin(tt * 2f)
                head = -4f
            }
            "listen" -> {
                head = -8f
                armR = -14f
                eyeOpen = 1.15f
                pulseSpeed = 12f
            }
            "think" -> {
                eyeDx = 4f
                eyeDy = -3f
                head = 6f
                armR = -150f
                pulseSpeed = 14f
            }
            "talk" -> {
                talk = true
                head = -3f
                armL = 12f
                armR = -18f + 8f * sin(tt * 5f)
            }
            "work" -> {
                eyeDy = 3f
                armL = -60f + 12f * sin(tt * 14f)
                armR = 60f - 12f * sin(tt * 14f + 1.5f)
                prop = 2
                pulseSpeed = 10f
                head = 5f
            }
        }

        val pulse = 0.5f + 0.5f * sin(tt * pulseSpeed)

        c.translate(0f, bob)

        // legs
        rot(c, legL, 46f, 118f) {
            rr(c, 40f, 118f, 53f, 142f, 6.5f, limb)
            oval(c, 35f, 136.5f, 57f, 147.5f, shellD)
        }
        rot(c, legR, 74f, 118f) {
            rr(c, 67f, 118f, 80f, 142f, 6.5f, limb)
            oval(c, 63f, 136.5f, 85f, 147.5f, shellD)
        }

        // body
        rr(c, 32f, 78f, 88f, 124f, 20f, shell)
        rr(c, 46f, 92f, 74f, 110f, 9f, screen)
        dot(c, 60f, 101f, 5f * (0.85f + 0.2f * pulse), glow)

        // arms
        rot(c, armL, 25f, 90f) {
            rr(c, 19f, 88f, 31f, 118f, 6f, limb)
            dot(c, 25f, 118f, 6.5f, shellD)
        }
        rot(c, armR, 95f, 90f) {
            rr(c, 89f, 88f, 101f, 118f, 6f, limb)
            dot(c, 95f, 118f, 6.5f, shellD)
        }

        // head
        rot(c, head, 60f, 80f) {
            p.style = Paint.Style.STROKE
            p.color = limb
            p.strokeWidth = 4f
            p.strokeCap = Paint.Cap.ROUND
            c.drawLine(60f, 20f, 60f, 9f, p)
            p.style = Paint.Style.FILL
            dot(c, 60f, 7f, 5.5f * (0.9f + 0.15f * pulse), glow, (170 + 85 * pulse).toInt())
            rr(c, 12f, 38f, 22f, 60f, 5f, shellD)
            rr(c, 98f, 38f, 108f, 60f, 5f, shellD)
            rr(c, 20f, 18f, 100f, 80f, 26f, shell)
            rr(c, 28f, 28f, 92f, 70f, 18f, screen)
            val ry = 7.5f * eyeOpen
            oval(c, 41f + eyeDx, 46f + eyeDy - ry, 53f + eyeDx, 46f + eyeDy + ry, eye)
            oval(c, 67f + eyeDx, 46f + eyeDy - ry, 79f + eyeDx, 46f + eyeDy + ry, eye)
            dot(c, 37f, 58f, 4f, cheek, 190)
            dot(c, 83f, 58f, 4f, cheek, 190)
            if (talk) {
                val open = 1f + 3.5f * abs(sin(tt * 18f))
                oval(c, 55f, 59f - open, 65f, 59f + open, eye)
            } else {
                p.style = Paint.Style.STROKE
                p.color = eye
                p.strokeWidth = 2.6f
                p.strokeCap = Paint.Cap.ROUND
                path.reset()
                path.moveTo(53f, 57f)
                path.quadTo(60f, 63f, 67f, 57f)
                c.drawPath(path, p)
                p.style = Paint.Style.FILL
            }
        }

        // props
        if (prop == 1) {
            rr(c, 38f, 96f, 82f, 122f, 4f, 0xFFFF8AA1.toInt())
            rr(c, 42f, 99f, 78f, 119f, 2f, 0xFFFFF6F8.toInt())
            p.style = Paint.Style.STROKE
            p.color = 0xFFFF8AA1.toInt()
            p.strokeWidth = 2f
            c.drawLine(60f, 99f, 60f, 119f, p)
            p.style = Paint.Style.FILL
        } else if (prop == 2) {
            rr(c, 40f, 94f, 80f, 124f, 5f, 0xFF2B3566.toInt())
            for (i in 0..2) {
                val len = 12f + 14f * abs(sin(tt * 3f + i))
                rr(c, 46f, 101f + i * 8f, 46f + len, 105f + i * 8f, 2f, eye)
            }
        }

        // floating extras
        p.style = Paint.Style.FILL
        if (zzz) {
            p.color = limb
            p.textSize = 14f
            p.alpha = (255 * (1f - (tt * 0.8f) % 1f)).toInt()
            c.drawText("Z", 94f, 20f - ((tt * 10f) % 12f), p)
            p.textSize = 18f
            p.alpha = (255 * (1f - (tt * 0.8f + 0.5f) % 1f)).toInt()
            c.drawText("Z", 102f, 12f - ((tt * 10f + 6f) % 12f), p)
            p.alpha = 255
        }
        if (notes) {
            p.color = glow
            p.textSize = 20f
            p.alpha = (255 * (1f - (tt * 0.7f) % 1f)).toInt()
            c.drawText("♪", 2f, 34f - ((tt * 14f) % 16f), p)
            p.alpha = (255 * (1f - (tt * 0.7f + 0.5f) % 1f)).toInt()
            c.drawText("♫", 104f, 30f - ((tt * 14f + 8f) % 16f), p)
            p.alpha = 255
        }
    }
}
