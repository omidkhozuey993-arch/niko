package ir.niko.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Persian speech in (Android speech recognizer) and out (Android text-to-speech). Main thread only. */
class Voice(
    private val ctx: Context,
    private val onHeard: (String) -> Unit,
    private val onProblem: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var paused = false
    private var speaking = false

    var active = false
        private set

    private val restart = Runnable { begin() }

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("fa", "IR")) ?: TextToSpeech.LANG_NOT_SUPPORTED
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                tts?.setPitch(1.35f)
            }
        }
    }

    fun start() {
        active = true
        paused = false
        main.post { begin() }
    }

    fun stop() {
        active = false
        main.removeCallbacks(restart)
        destroyRec()
    }

    fun shutdown() {
        stop()
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    fun speak(text: String, done: () -> Unit) {
        val t = tts
        if (t == null || !ttsReady) {
            // No Persian voice installed: just show the text for a while.
            main.postDelayed({ done() }, (1500L + text.length * 70L).coerceAtMost(9000L))
            return
        }
        speaking = true
        pauseListening()
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}

            override fun onDone(utteranceId: String?) {
                main.post { afterSpeech(done) }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                main.post { afterSpeech(done) }
            }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "niko")
    }

    private fun afterSpeech(done: () -> Unit) {
        speaking = false
        paused = false
        if (active) scheduleRestart(350)
        done()
    }

    private fun pauseListening() {
        paused = true
        main.removeCallbacks(restart)
        try {
            rec?.cancel()
        } catch (_: Exception) {
        }
    }

    private fun scheduleRestart(ms: Long) {
        main.removeCallbacks(restart)
        main.postDelayed(restart, ms)
    }

    private fun destroyRec() {
        try {
            rec?.destroy()
        } catch (_: Exception) {
        }
        rec = null
    }

    private fun begin() {
        if (!active || paused || speaking) return
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            active = false
            onProblem("تشخیص گفتار روی این گوشی نصب نیست")
            return
        }
        if (rec == null) {
            rec = SpeechRecognizer.createSpeechRecognizer(ctx).also { it.setRecognitionListener(listener) }
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fa-IR")
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        try {
            rec?.startListening(i)
        } catch (e: Exception) {
            destroyRec()
            scheduleRestart(1500)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onResults(results: Bundle?) {
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val best = list?.firstOrNull()
            if (!best.isNullOrBlank()) onHeard(best)
            if (active && !paused) scheduleRestart(250)
        }

        override fun onError(error: Int) {
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    active = false
                    onProblem("اجازه‌ی میکروفون داده نشده")
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    destroyRec()
                    if (active && !paused) scheduleRestart(1200)
                }
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    if (active && !paused) scheduleRestart(150)
                }
                else -> {
                    if (active && !paused) scheduleRestart(900)
                }
            }
        }
    }
}
