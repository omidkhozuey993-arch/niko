package ir.niko.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/** Setup screen: key, permissions, and the wake-up button. */
class MainActivity : Activity() {

    private lateinit var col: LinearLayout
    private lateinit var keyBox: EditText
    private lateinit var stKey: TextView
    private lateinit var stOverlay: TextView
    private lateinit var stMic: TextView
    private lateinit var stAccess: TextView
    private lateinit var stTts: TextView
    private lateinit var startBtn: Button
    private var tts: TextToSpeech? = null
    private var ttsOk = false

    private val ink = Color.parseColor("#1B2340")
    private val soft = Color.parseColor("#566082")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#EEF3FB"))
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.layoutDirection = View.LAYOUT_DIRECTION_RTL
        col.setPadding(dp(20), dp(28), dp(20), dp(40))
        scroll.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(scroll)

        add(tv("نیکو", 34f, true), 0)
        add(tv("یه ربات کوچولو که روی همه‌ی صفحه‌ها راه می‌ره، باهات حرف می‌زنه و کارهای گوشی رو برات انجام می‌ده.", 15f, false, soft), 4)

        // 1. API key
        add(tv("۱) کلید API", 17f, true), 24)
        stKey = tv("", 14f, false, soft)
        add(stKey, 2)
        add(tv("نیکو برای فکر کردن از Claude استفاده می‌کنه. کلید رو از console.anthropic.com بگیر. هزینه‌ی هر گفتگو از اعتبار حساب خودته.", 13f, false, soft), 2)
        keyBox = EditText(this)
        keyBox.hint = "sk-ant-..."
        keyBox.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        keyBox.layoutDirection = View.LAYOUT_DIRECTION_LTR
        keyBox.setText(Prefs.apiKey(this))
        add(keyBox, 6)
        add(btn("ذخیره‌ی کلید") {
            Prefs.setApiKey(this, keyBox.text.toString())
            Toast.makeText(this, "ذخیره شد", Toast.LENGTH_SHORT).show()
            refresh()
        }, 4)

        // 2. overlay
        add(tv("۲) نمایش روی بقیه‌ی برنامه‌ها", 17f, true), 24)
        stOverlay = tv("", 14f, false, soft)
        add(stOverlay, 2)
        add(btn("باز کردن تنظیم") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }, 4)

        // 3. mic + notifications
        add(tv("۳) میکروفون و اعلان", 17f, true), 24)
        stMic = tv("", 14f, false, soft)
        add(stMic, 2)
        add(btn("اجازه دادن") {
            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        }, 4)

        // 4. accessibility
        add(tv("۴) دسترسی به صفحه (برای انجام کارها)", 17f, true), 24)
        stAccess = tv("", 14f, false, soft)
        add(stAccess, 2)
        add(tv("با این، نیکو می‌تونه تنظیمات رو باز کنه و روی دکمه‌ها بزنه. فقط وقتی کاری ازش بخوای استفاده می‌شه. توی لیست، «نیکو» رو پیدا کن و روشنش کن.", 13f, false, soft), 2)
        add(btn("باز کردن تنظیمات دسترسی") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, 4)
        add(tv("اگه گزینه خاکستری بود و روشن نشد: روی دکمه‌ی پایین بزن، بعد سه‌نقطه‌ی بالا و «Allow restricted settings» رو بزن و دوباره برگرد.", 13f, false, soft), 6)
        add(btn("باز کردن اطلاعات برنامه") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }, 4)

        // 5. voice
        add(tv("۵) صدای فارسی", 17f, true), 24)
        stTts = tv("", 14f, false, soft)
        add(stTts, 2)
        add(btn("نصب یا انتخاب صدای فارسی") {
            try {
                startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA))
            } catch (e: Exception) {
                try {
                    startActivity(Intent("com.android.settings.TTS_SETTINGS"))
                } catch (e2: Exception) {
                    Toast.makeText(this, "تنظیمات تبدیل متن به گفتار رو دستی باز کن", Toast.LENGTH_LONG).show()
                }
            }
        }, 4)

        // 6. listening mode
        add(tv("۶) گوش دادن", 17f, true), 24)
        val sw = Switch(this)
        sw.text = "همیشه گوش بده (با گفتن «نیکو» بیدار می‌شه)"
        sw.isChecked = Prefs.alwaysListen(this)
        sw.setOnCheckedChangeListener { _, on -> Prefs.setAlwaysListen(this, on) }
        add(sw, 6)
        add(tv("اگه خاموش باشه، فقط وقتی روی خود نیکو بزنی گوش می‌ده. باتری کمتر مصرف می‌شه.", 13f, false, soft), 2)

        // go
        startBtn = btn("") { onStartClick() }
        startBtn.textSize = 18f
        add(startBtn, 28)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.isLanguageAvailable(Locale("fa", "IR")) ?: TextToSpeech.LANG_NOT_SUPPORTED
                ttsOk = r >= TextToSpeech.LANG_AVAILABLE
                runOnUiThread { refresh() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun micOk() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun accessOk(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains("$packageName/")
    }

    private fun mark(v: TextView, ok: Boolean, good: String, bad: String) {
        v.text = if (ok) "✓ $good" else "○ $bad"
        v.setTextColor(if (ok) Color.parseColor("#1E8E5A") else soft)
    }

    private fun refresh() {
        mark(stKey, Prefs.apiKey(this).isNotBlank(), "کلید ذخیره شده", "هنوز کلیدی وارد نشده")
        mark(stOverlay, Settings.canDrawOverlays(this), "اجازه داده شده", "اجازه داده نشده")
        mark(stMic, micOk(), "میکروفون آماده‌ست", "میکروفون اجازه نداره")
        mark(stAccess, accessOk(), "روشنه", "خاموشه (بدون اون نیکو فقط حرف می‌زنه)")
        mark(stTts, ttsOk, "صدای فارسی نصبه", "صدای فارسی پیدا نشد (نیکو فقط با متن جواب می‌ده)")
        startBtn.text = if (NikoService.running) "نیکو رو بخوابون" else "نیکو رو بیدار کن"
    }

    private fun onStartClick() {
        if (NikoService.running) {
            NikoService.stop(this)
            startBtn.postDelayed({ refresh() }, 500)
            return
        }
        val missing = mutableListOf<String>()
        if (Prefs.apiKey(this).isBlank()) missing.add("کلید API")
        if (!Settings.canDrawOverlays(this)) missing.add("نمایش روی برنامه‌ها")
        if (!micOk()) missing.add("میکروفون")
        if (missing.isNotEmpty()) {
            Toast.makeText(this, "اول اینا رو درست کن: " + missing.joinToString("، "), Toast.LENGTH_LONG).show()
            return
        }
        NikoService.start(this)
        startBtn.postDelayed({ refresh() }, 800)
        moveTaskToBack(true)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun tv(s: String, size: Float, bold: Boolean, color: Int = ink): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun btn(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    private fun add(v: View, topDp: Int) {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(topDp)
        col.addView(v, lp)
    }
}
