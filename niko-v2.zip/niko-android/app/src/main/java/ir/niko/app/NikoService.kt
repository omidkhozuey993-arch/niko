package ir.niko.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.random.Random

/**
 * Niko's life. Draws him over every app, makes him wander, listens for his name,
 * and hands what you say to Claude.
 */
class NikoService : Service() {

    companion object {
        @Volatile
        var running = false
        private const val CH = "niko"
        private val NAME = Regex("نیکو+|niko+|nico+")

        fun start(ctx: android.content.Context) {
            ctx.startForegroundService(Intent(ctx, NikoService::class.java))
        }

        fun stop(ctx: android.content.Context) {
            ctx.stopService(Intent(ctx, NikoService::class.java))
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private val choreo: Choreographer by lazy { Choreographer.getInstance() }

    private lateinit var wm: WindowManager
    private lateinit var view: NikoView
    private lateinit var bubble: TextView
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var blp: WindowManager.LayoutParams
    private lateinit var voice: Voice
    private lateinit var brain: Brain

    private var robotW = 0
    private var robotH = 0
    private var x = 0f
    private var y = 0f
    private var target = 0f
    private var speed = 0f

    private var act = "idle"
    private var actEnd = 0L
    private var nextAt = 0L
    private var lastPick = ""
    private var lastNs = 0L

    private var dragging = false
    private var busy = false
    private var thinking = false
    private var awaitUntil = 0L

    private val lines = mapOf(
        "walk" to listOf("یه کم قدم بزنم", "هوا چه خوبه!", "لا لا لا…", "دارم گوشی رو بازرسی می‌کنم"),
        "dance" to listOf("حس رقص دارم!", "یک، دو، سه، بچرخ!", "باتریم پر انرژیه"),
        "wave" to listOf("سلام! من اینجام", "هی، منو می‌بینی؟"),
        "read" to listOf("این کتاب خیلی جالبه", "هوم… جالب شد")
    )

    private val hideBubble = Runnable {
        bubble.visibility = View.GONE
        try {
            wm.updateViewLayout(bubble, blp)
        } catch (_: Exception) {
        }
    }

    private val awaitEnd = Runnable {
        if (!thinking && SystemClock.uptimeMillis() >= awaitUntil) {
            busy = false
            setAct("idle")
            nextAt = SystemClock.uptimeMillis() + 1500
            if (!Prefs.alwaysListen(this)) voice.stop()
        }
    }

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            val dt = if (lastNs == 0L) 0f else ((frameTimeNanos - lastNs) / 1e9f).coerceAtMost(0.05f)
            lastNs = frameTimeNanos
            tick(dt)
            choreo.postFrameCallback(this)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") stopSelf()
        return START_NOT_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        try {
            startAsForeground()
        } catch (e: Exception) {
            Toast.makeText(this, "نیکو نتونست شروع کنه: " + e.message, Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        try {
            setupOverlay()
        } catch (e: Exception) {
            Toast.makeText(this, "اجازه‌ی نمایش روی برنامه‌ها لازمه", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        running = true
        brain = Brain(this)
        voice = Voice(this, { heard(it) }, { msg -> main.post { say(msg, 6000) } })
        if (Prefs.alwaysListen(this)) voice.start()
        nextAt = SystemClock.uptimeMillis() + 2500
        choreo.postFrameCallback(frame)
        main.postDelayed({ say("سلام! من نیکو هستم. صدام کن!", 4500) }, 700)
    }

    override fun onDestroy() {
        running = false
        choreo.removeFrameCallback(frame)
        main.removeCallbacksAndMessages(null)
        exec.shutdownNow()
        if (this::voice.isInitialized) voice.shutdown()
        if (this::wm.isInitialized) {
            try {
                wm.removeView(view)
            } catch (_: Exception) {
            }
            try {
                wm.removeView(bubble)
            } catch (_: Exception) {
            }
        }
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "نیکو", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, NikoService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("نیکو بیداره")
            .setContentText("بزن تا نیکو بره بخوابه")
            .setContentIntent(stopPi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    private fun setupOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = resources.displayMetrics
        robotW = dp(108)
        robotH = dp(135)
        speed = dp(55).toFloat()
        x = dp(20).toFloat()
        y = (dm.heightPixels - robotH - dp(90)).toFloat()
        target = x

        view = NikoView(this)
        view.contentDescription = "نیکو"
        lp = WindowManager.LayoutParams(
            robotW, robotH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = x.toInt()
        lp.y = y.toInt()
        wm.addView(view, lp)

        bubble = TextView(this)
        bubble.textSize = 15f
        bubble.setTextColor(Color.parseColor("#1B2340"))
        bubble.gravity = Gravity.CENTER
        bubble.layoutDirection = View.LAYOUT_DIRECTION_RTL
        bubble.maxWidth = dp(240)
        bubble.setPadding(dp(14), dp(9), dp(14), dp(9))
        val bg = GradientDrawable()
        bg.setColor(Color.WHITE)
        bg.cornerRadius = dp(16).toFloat()
        bg.setStroke(dp(1), Color.parseColor("#D6DEEE"))
        bubble.background = bg
        bubble.visibility = View.GONE
        blp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        blp.gravity = Gravity.TOP or Gravity.START
        wm.addView(bubble, blp)

        installTouch()
    }

    private fun installTouch() {
        val slop = ViewConfiguration.get(this).scaledTouchSlop.toFloat()
        var downX = 0f
        var downY = 0f
        var startX = 0f
        var startY = 0f
        var moved = false
        view.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = x
                    startY = y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) {
                        moved = true
                        dragging = true
                        if (!busy) setAct("idle")
                    }
                    if (moved) {
                        val dm = resources.displayMetrics
                        x = (startX + dx).coerceIn(0f, (dm.widthPixels - robotW).toFloat())
                        y = (startY + dy).coerceIn(0f, (dm.heightPixels - robotH).toFloat())
                        layoutRobot()
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (moved) {
                        dragging = false
                        nextAt = SystemClock.uptimeMillis() + 1500
                    } else if (e.actionMasked == MotionEvent.ACTION_UP) {
                        callNiko()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun layoutRobot() {
        lp.x = x.toInt()
        lp.y = y.toInt()
        try {
            wm.updateViewLayout(view, lp)
        } catch (_: Exception) {
        }
        layoutBubble()
    }

    private fun layoutBubble() {
        if (bubble.visibility != View.VISIBLE) return
        bubble.measure(
            View.MeasureSpec.makeMeasureSpec(dp(240), View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val dm = resources.displayMetrics
        val bw = bubble.measuredWidth
        val bh = bubble.measuredHeight
        val maxBx = (dm.widthPixels - bw - dp(4)).toFloat().coerceAtLeast(dp(4).toFloat())
        val bx = (x + robotW / 2f - bw / 2f).coerceIn(dp(4).toFloat(), maxBx)
        val by = (y - bh - dp(2)).coerceAtLeast(dp(24).toFloat())
        blp.x = bx.toInt()
        blp.y = by.toInt()
        try {
            wm.updateViewLayout(bubble, blp)
        } catch (_: Exception) {
        }
    }

    private fun say(t: String, ms: Long = 3000) {
        bubble.text = t
        bubble.visibility = View.VISIBLE
        layoutBubble()
        main.removeCallbacks(hideBubble)
        main.postDelayed(hideBubble, ms)
    }

    private fun setAct(a: String) {
        act = a
        view.act = a
    }

    /* ---------- his own life ---------- */

    private fun tick(dt: Float) {
        if (dragging || busy) return
        val now = SystemClock.uptimeMillis()
        when (act) {
            "walk" -> {
                val dx = target - x
                val step = speed * dt
                if (abs(dx) <= step) {
                    x = target
                    toIdle(now)
                } else {
                    x += if (dx > 0) step else -step
                }
                layoutRobot()
            }
            "idle" -> if (now >= nextAt) pickNext(now)
            else -> if (now >= actEnd) toIdle(now)
        }
    }

    private fun toIdle(now: Long) {
        setAct("idle")
        nextAt = now + Random.nextLong(800, 2600)
    }

    private fun line(k: String): String = lines[k]!!.random()

    private fun pickNext(now: Long) {
        val dm = resources.displayMetrics
        val maxX = (dm.widthPixels - robotW).toFloat().coerceAtLeast(0f)
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val night = hour >= 22 || hour < 6
        var pick = "walk"
        do {
            val r = Random.nextInt(100)
            pick = if (night && r < 40) "sleep" else when {
                r < 38 -> "walk"
                r < 50 -> "look"
                r < 62 -> "wave"
                r < 76 -> "dance"
                r < 90 -> "read"
                else -> "sleep"
            }
        } while (pick == lastPick)
        lastPick = pick

        when (pick) {
            "walk" -> {
                target = Random.nextFloat() * maxX
                view.dir = if (target >= x) 1 else -1
                setAct("walk")
                if (Random.nextInt(100) < 35) say(line("walk"), 2600)
            }
            "look" -> {
                setAct("look")
                actEnd = now + 3600
                main.postDelayed({ if (act == "look") view.dir = -view.dir }, 1800)
            }
            "wave" -> {
                view.dir = if (Random.nextBoolean()) 1 else -1
                setAct("wave")
                actEnd = now + 3200
                say(line("wave"), 2800)
            }
            "dance" -> {
                setAct("dance")
                actEnd = now + 5200
                say(line("dance"), 3000)
            }
            "read" -> {
                setAct("read")
                actEnd = now + 7000
                say(line("read"), 2800)
            }
            else -> {
                setAct("sleep")
                actEnd = now + 9000
                say("خررر… خررر…", 3500)
            }
        }
    }

    /* ---------- talking ---------- */

    private fun norm(t: String): String =
        t.replace(Regex("[ً-ٰٟ]"), "")
            .replace('ي', 'ی')
            .replace('ك', 'ک')
            .replace('‌', ' ')
            .lowercase()

    private fun stripName(t: String): String =
        norm(t).replace(NAME, " ").replace(Regex("[،,.!؟?]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun heard(raw: String) {
        if (thinking) return
        val text = norm(raw)
        val now = SystemClock.uptimeMillis()
        if (NAME.containsMatchIn(text)) {
            val rest = stripName(raw)
            if (rest.length < 2) callNiko() else handleQuery(rest)
        } else if (now < awaitUntil) {
            handleQuery(raw.trim())
        }
    }

    private fun callNiko() {
        if (thinking) return
        busy = true
        setAct("listen")
        say("جانم؟", 6000)
        if (!voice.active) voice.start()
        awaitUntil = SystemClock.uptimeMillis() + 8000
        main.removeCallbacks(awaitEnd)
        main.postDelayed(awaitEnd, 8200)
        voice.speak("جانم؟") {
            awaitUntil = SystemClock.uptimeMillis() + 8000
            main.removeCallbacks(awaitEnd)
            main.postDelayed(awaitEnd, 8200)
        }
    }

    private fun handleQuery(q: String) {
        awaitUntil = 0
        main.removeCallbacks(awaitEnd)
        busy = true
        thinking = true
        setAct("think")
        say("هوم…", 60000)
        exec.execute {
            val reply = brain.ask(q) {
                main.post {
                    setAct("work")
                    say("دارم کارتو انجام می‌دم…", 60000)
                }
            }
            main.post {
                setAct("talk")
                say(reply, (3000L + reply.length * 90L).coerceAtMost(15000L))
                voice.speak(reply) { finishTalk() }
            }
        }
    }

    private fun finishTalk() {
        thinking = false
        busy = false
        awaitUntil = SystemClock.uptimeMillis() + 8000
        setAct("idle")
        nextAt = SystemClock.uptimeMillis() + 2500
        if (!Prefs.alwaysListen(this)) {
            main.postDelayed({ if (!busy) voice.stop() }, 9000)
        }
    }
}
