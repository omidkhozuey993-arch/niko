package ir.niko.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.util.SparseArray
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Lets Niko see the current screen and press things on it, like a person would.
 * Everything here only runs when the user asks Niko to do something.
 */
class NikoAccess : AccessibilityService() {

    companion object {
        @Volatile
        var instance: NikoAccess? = null
    }

    private val nodes = SparseArray<AccessibilityNodeInfo>()

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    @Synchronized
    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "screen is empty or not readable"
        nodes.clear()
        val sb = StringBuilder("app: ").append(root.packageName).append('\n')
        walk(root, sb)
        return sb.toString().take(7000)
    }

    private fun walk(n: AccessibilityNodeInfo?, sb: StringBuilder) {
        if (n == null || nodes.size() > 350) return
        if (n.isVisibleToUser) {
            val text = if (n.isPassword) "" else (n.text?.toString() ?: "")
            val desc = n.contentDescription?.toString() ?: ""
            val interesting = text.isNotEmpty() || desc.isNotEmpty() ||
                n.isClickable || n.isEditable || n.isScrollable || n.isCheckable
            if (interesting) {
                val id = nodes.size()
                nodes.put(id, n)
                sb.append('[').append(id).append("] ")
                sb.append(n.className?.toString()?.substringAfterLast('.') ?: "View")
                if (text.isNotEmpty()) sb.append(" \"").append(text.take(80)).append('"')
                if (desc.isNotEmpty() && desc != text) sb.append(" desc=\"").append(desc.take(60)).append('"')
                if (n.isClickable) sb.append(" clickable")
                if (n.isEditable) sb.append(" editable")
                if (n.isScrollable) sb.append(" scrollable")
                if (n.isCheckable) sb.append(if (n.isChecked) " checked" else " unchecked")
                if (n.isPassword) sb.append(" password-field(hidden)")
                sb.append('\n')
            }
        }
        for (i in 0 until n.childCount) {
            walk(n.getChild(i), sb)
        }
    }

    @Synchronized
    fun tap(id: Int): String {
        val start = nodes.get(id) ?: return "error: id $id not found, call read_screen again"
        var n: AccessibilityNodeInfo? = start
        var hops = 0
        while (n != null && !n.isClickable && hops < 6) {
            n = n.parent
            hops++
        }
        if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "tapped"
        val r = Rect()
        start.getBoundsInScreen(r)
        return if (tapAt(r.centerX().toFloat(), r.centerY().toFloat())) "tapped by gesture" else "error: tap failed"
    }

    fun tapAt(x: Float, y: Float): Boolean {
        val p = Path()
        p.moveTo(x, y)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60))
            .build()
        return dispatchGesture(g, null, null)
    }

    @Synchronized
    fun setText(id: Int, text: String): String {
        val n = nodes.get(id) ?: return "error: id $id not found, call read_screen again"
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return if (n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "ok" else "error: could not set text"
    }

    @Synchronized
    fun scroll(down: Boolean): String {
        for (i in 0 until nodes.size()) {
            val n = nodes.valueAt(i)
            if (n.isScrollable) {
                val action = if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                if (n.performAction(action)) return "scrolled"
            }
        }
        return "error: nothing to scroll (call read_screen first)"
    }
}
