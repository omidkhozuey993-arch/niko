package ir.niko.app

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("niko", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = sp(c).getString("key", "") ?: ""

    fun setApiKey(c: Context, v: String) {
        sp(c).edit().putString("key", v.trim()).apply()
    }

    fun alwaysListen(c: Context): Boolean = sp(c).getBoolean("always", true)

    fun setAlwaysListen(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("always", v).apply()
    }
}
